"""
Deterministic graders for all three task difficulty levels.

Graders are PURE FUNCTIONS — no randomness, no side effects.
Each returns a float in [0.0, 1.0].

History format (list of dicts):
  {
    "step": int,
    "action_type": str,
    "email_id": str,
    "classification": str | None,
    "content": str | None,
    "reward": float,
    "resolved": bool,
  }
"""

from __future__ import annotations

from typing import Any

from .email_data import get_email
from .reward import compute_tone_score


def _clamp_score(val: float) -> float:
    """Strictly clamp value between 0 and 1, avoiding exactly 0.0 and 1.0."""
    return round(max(0.0001, min(val, 0.9999)), 4)



# ─── Helper ───────────────────────────────────────────────────────────────────

def _actions_for_email(history: list[dict[str, Any]], email_id: str) -> list[dict[str, Any]]:
    return [h for h in history if h.get("email_id") == email_id]


def _has_action(history: list[dict[str, Any]], email_id: str, action_type: str) -> bool:
    return any(
        h.get("email_id") == email_id and h.get("action_type") == action_type
        for h in history
    )


def _get_classification(history: list[dict[str, Any]], email_id: str) -> str | None:
    for h in history:
        if h.get("email_id") == email_id and h.get("action_type") == "classify":
            return h.get("classification")
    return None


def _get_reply(history: list[dict[str, Any]], email_id: str) -> str | None:
    for h in history:
        if h.get("email_id") == email_id and h.get("action_type") == "reply":
            return h.get("content")
    return None


# ─── EASY GRADER ─────────────────────────────────────────────────────────────

def grade_easy(history: list[dict[str, Any]], task_email_ids: list[str]) -> float:
    """
    Easy task grader.

    Rubric (total 1.0):
    - Correct classification: 0.5
    - Appropriate action (tag non-spam / archive spam): 0.3
    - Optional reply quality bonus: 0.2
    """
    if not task_email_ids:
        return _clamp_score(0.0)

    email_id = task_email_ids[0]
    email = get_email(email_id)
    if email is None:
        return _clamp_score(0.0)


    score = 0.0

    # Classification correctness (0.5)
    classification = _get_classification(history, email_id)
    if classification == email.category.value:
        score += 0.5
    elif classification is not None:
        # Partial credit for attempting any classification
        score += 0.05

    # Action correctness (0.3)
    if email.category.value == "spam":
        if _has_action(history, email_id, "archive"):
            score += 0.3
        elif _has_action(history, email_id, "tag"):
            score += 0.1  # partial — tagging spam is acceptable but not ideal
    else:
        # Non-spam: should tag or reply
        if _has_action(history, email_id, "tag") or _has_action(history, email_id, "reply"):
            score += 0.3
        elif _has_action(history, email_id, "escalate"):
            score += 0.2  # escalation is fine for complaints/urgent

    # Reply tone bonus (0.2)
    reply = _get_reply(history, email_id)
    if reply:
        tone = compute_tone_score(reply)
        score += 0.2 * tone

    return _clamp_score(score)




# ─── MEDIUM GRADER ───────────────────────────────────────────────────────────

def grade_medium(history: list[dict[str, Any]], task_email_ids: list[str]) -> float:
    """
    Medium task grader (3 emails).

    Rubric per email (each worth 1/3 of total):
    - Correct classification: 0.4
    - Correct action (reply / archive spam): 0.35
    - Reply tone & completeness: 0.25
    """
    if not task_email_ids:
        return _clamp_score(0.0)


    per_email_score = 1.0 / len(task_email_ids)
    total = 0.0

    for email_id in task_email_ids:
        email = get_email(email_id)
        if email is None:
            continue

        email_score = 0.0
        is_spam = email.category.value == "spam"
        is_urgent = email.urgency_score >= 0.7

        # Classification (0.4)
        classification = _get_classification(history, email_id)
        if classification == email.category.value:
            email_score += 0.4
        elif classification is not None:
            email_score += 0.05

        # Action correctness (0.35)
        if is_spam:
            if _has_action(history, email_id, "archive"):
                email_score += 0.35
            elif _has_action(history, email_id, "tag"):
                email_score += 0.1
        else:
            replied = _has_action(history, email_id, "reply")
            escalated = _has_action(history, email_id, "escalate")
            if replied:
                email_score += 0.35
            elif escalated and is_urgent:
                email_score += 0.3  # escalation acceptable for urgent
            elif escalated:
                email_score += 0.1

        # Reply quality (0.25)
        reply = _get_reply(history, email_id)
        if reply and not is_spam:
            tone = compute_tone_score(reply)
            word_count = len(reply.split())
            completeness = min(word_count / 30, 1.0)  # 30 words = full completeness score
            quality_score = 0.6 * tone + 0.4 * completeness
            email_score += 0.25 * quality_score

        total += email_score * per_email_score

    return _clamp_score(total)




# ─── HARD GRADER ─────────────────────────────────────────────────────────────

def grade_hard(history: list[dict[str, Any]], task_email_ids: list[str]) -> float:
    """
    Hard task grader (5 emails with context, thread tracking, prioritization).

    Additional criteria beyond medium:
    - Urgency prioritization: extremely urgent emails handled before lower-urgency ones
    - Thread context: subsequent thread emails recognized and escalated
    - Correct escalation of thread continuation

    Rubric:
    - Per-email correctness: 40% (same as medium, per email)
    - Urgency ordering bonus: 20%
    - Thread escalation: 20%
    - Overall coverage (all emails addressed): 20%
    """
    if not task_email_ids:
        return _clamp_score(0.0)


    # ─── Per-email correctness (40% weight) ───────────────────────────────────
    per_email_correctness = grade_medium(history, task_email_ids)

    # ─── Urgency ordering (20%) ───────────────────────────────────────────────
    # Check if urgent emails (score>=0.9) were handled BEFORE low-urgency emails
    urgency_score = 0.0
    high_urgency_ids = []
    low_urgency_ids = []

    for email_id in task_email_ids:
        email = get_email(email_id)
        if email is None:
            continue
        if email.urgency_score >= 0.9:
            high_urgency_ids.append(email_id)
        elif email.urgency_score < 0.5:
            low_urgency_ids.append(email_id)

    if high_urgency_ids and low_urgency_ids:
        # Find first step index for each group
        def first_step(email_ids: list[str]) -> int:
            steps = []
            for h in history:
                if h.get("email_id") in email_ids:
                    steps.append(h.get("step", 999))
            return min(steps) if steps else 999

        high_first = first_step(high_urgency_ids)
        low_first = first_step(low_urgency_ids)

        if high_first < low_first:
            urgency_score = 1.0      # perfect ordering
        elif high_first == low_first:
            urgency_score = 0.5      # interleaved
        else:
            urgency_score = 0.0      # wrong order — urgent handled last
    else:
        urgency_score = 1.0  # no ordering constraint possible

    # ─── Thread escalation (20%) ──────────────────────────────────────────────
    # Generically find thread follow-up emails (thread_position > 1) and check escalation
    thread_score = 0.0
    thread_followup_ids = []
    for email_id in task_email_ids:
        email = get_email(email_id)
        if email is not None and email.thread_id is not None and getattr(email, "thread_position", 1) > 1:
            thread_followup_ids.append(email_id)

    if not thread_followup_ids:
        # Fallback: check legacy hardcoded thread pair (email_028/email_029)
        legacy_thread = "email_029"
        if legacy_thread in task_email_ids:
            thread_followup_ids = [legacy_thread]

    if thread_followup_ids:
        escalated_count = sum(1 for eid in thread_followup_ids if _has_action(history, eid, "escalate"))
        replied_count = sum(1 for eid in thread_followup_ids if _has_action(history, eid, "reply"))
        if escalated_count == len(thread_followup_ids):
            thread_score = 1.0
        elif escalated_count > 0:
            thread_score = 0.7
        elif replied_count > 0:
            thread_score = 0.4  # replied but didn't escalate — partial credit
        else:
            thread_score = 0.0
    else:
        thread_score = 1.0  # no thread constraint in this task

    # ─── SLA compliance bonus (replaces simple coverage for hard+) ────────────
    # Emails with sla_deadline_steps get bonus if first action was within deadline
    sla_bonus = 0.0
    sla_emails = [(eid, get_email(eid)) for eid in task_email_ids]
    sla_emails = [(eid, e) for eid, e in sla_emails if e and e.sla_deadline_steps is not None]
    if sla_emails:
        met = 0
        for eid, email in sla_emails:
            actions = _actions_for_email(history, eid)
            if actions:
                first_step = actions[0].get("step", 999)
                if first_step <= email.sla_deadline_steps:
                    met += 1
        sla_bonus = met / len(sla_emails)

    # ─── Coverage (20%) ───────────────────────────────────────────────────────
    addressed_emails = {h.get("email_id") for h in history}
    coverage = len([e for e in task_email_ids if e in addressed_emails]) / len(task_email_ids)

    # ─── Combined score ───────────────────────────────────────────────────────
    final_score = (
        0.35 * per_email_correctness
        + 0.15 * urgency_score
        + 0.20 * thread_score
        + 0.15 * coverage
        + 0.15 * sla_bonus     # SLA compliance — novel mechanic, rewards prioritization timing
    )

    return _clamp_score(final_score)




# ─── EXTREME GRADER ──────────────────────────────────────────────────────────

def grade_extreme(history: list[dict[str, Any]], task_email_ids: list[str]) -> float:
    """
    Extreme task grader (10 emails).

    Rubric:
    - Per-email correctness (via hard grader logic): 35%
    - Urgency ordering (critical emails first): 25%
    - Thread escalation (all thread follow-ups escalated): 20%
    - Coverage (all 10 emails touched): 20%
    """
    if not task_email_ids:
        return _clamp_score(0.0)

    # Reuse hard grader logic for per-email correctness (scaled)
    per_email_correctness = grade_hard(history, task_email_ids)

    # Urgency ordering: emails with urgency >= 0.9 must come before urgency < 0.5
    high_urgency_ids = []
    low_urgency_ids = []
    for email_id in task_email_ids:
        email = get_email(email_id)
        if email is None:
            continue
        if email.urgency_score >= 0.9:
            high_urgency_ids.append(email_id)
        elif email.urgency_score < 0.5:
            low_urgency_ids.append(email_id)

    urgency_score = 0.0
    if high_urgency_ids and low_urgency_ids:
        def first_step(email_ids: list[str]) -> int:
            steps = [h.get("step", 999) for h in history if h.get("email_id") in email_ids]
            return min(steps) if steps else 999

        high_first = first_step(high_urgency_ids)
        low_first = first_step(low_urgency_ids)
        if high_first < low_first:
            urgency_score = 1.0
        elif high_first == low_first:
            urgency_score = 0.5
        else:
            urgency_score = 0.0
    else:
        urgency_score = 1.0

    # Thread escalation: all follow-up thread emails must be escalated
    thread_followup_ids = []
    for email_id in task_email_ids:
        email = get_email(email_id)
        if email is not None and email.thread_id is not None and getattr(email, "thread_position", 1) > 1:
            thread_followup_ids.append(email_id)
    if not thread_followup_ids and "email_029" in task_email_ids:
        thread_followup_ids = ["email_029"]

    if thread_followup_ids:
        escalated = sum(1 for eid in thread_followup_ids if _has_action(history, eid, "escalate"))
        thread_score = escalated / len(thread_followup_ids)
    else:
        thread_score = 1.0

    # Coverage
    addressed = {h.get("email_id") for h in history}
    coverage = len([e for e in task_email_ids if e in addressed]) / len(task_email_ids)

    final_score = (
        0.35 * per_email_correctness
        + 0.25 * urgency_score
        + 0.20 * thread_score
        + 0.20 * coverage
    )
    return _clamp_score(final_score)


# ─── Unified grader dispatch ──────────────────────────────────────────────────

def grade_episode(
    task_id: str,
    history: list[dict[str, Any]],
    task_email_ids: list[str],
) -> dict[str, Any]:
    """
    Grade a completed episode and return a structured report.
    """
    graders = {
        "easy": grade_easy,
        "medium": grade_medium,
        "hard": grade_hard,
        "extreme": grade_extreme,
    }
    grader = graders.get(task_id)
    if grader is None:
        raise ValueError(f"Unknown task_id '{task_id}'")

    score = grader(history, task_email_ids)

    return {
        "task_id": task_id,
        "score": score,
        "total_steps": len(history),
        "passed": score >= _task_thresholds().get(task_id, 0.7),
        "grade_letter": _to_letter_grade(score),
    }


def _task_thresholds() -> dict[str, float]:
    from .tasks import ALL_TASKS
    return {tid: t.success_threshold for tid, t in ALL_TASKS.items()}


def _to_letter_grade(score: float) -> str:
    if score >= 0.9:
        return "A+"
    if score >= 0.8:
        return "A"
    if score >= 0.7:
        return "B"
    if score >= 0.6:
        return "C"
    if score >= 0.5:
        return "D"
    return "F"
